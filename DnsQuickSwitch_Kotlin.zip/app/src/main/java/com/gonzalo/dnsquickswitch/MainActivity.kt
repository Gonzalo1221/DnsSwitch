package com.gonzalo.dnsquickswitch

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private var dnsEnabled = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val btnToggleDns: Button = findViewById(R.id.btnToggleDns)

        btnToggleDns.setOnClickListener {
            val intent = Intent(Settings.ACTION_PRIVATE_DNS_SETTINGS)
            startActivity(intent)
        }
    }
}
